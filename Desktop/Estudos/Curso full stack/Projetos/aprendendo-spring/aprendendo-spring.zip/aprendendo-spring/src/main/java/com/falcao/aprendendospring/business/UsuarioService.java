package com.falcao.aprendendospring.business;

import com.falcao.aprendendospring.infrastructure.entity.Usuario;
import com.falcao.aprendendospring.infrastructure.expections.ConflictExecption;
import com.falcao.aprendendospring.infrastructure.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor

public class UsuarioService {

    @Autowired
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public Usuario salvarUsuario(Usuario usuario) {
        try {
            emailExiste(usuario.getEmail());
             usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
            return usuarioRepository.save(usuario);
        } catch (ConflictExecption e) {
            throw new ConflictExecption("Email já cadastrado", e.getCause());
        }
    }

    public void emailExiste(String email) {
        try{
           boolean existe = verificaEmailExistente(email);
           if(existe){
               throw new ConflictExecption("Email já cadastrado" + email);
           }
        }catch (Exception e){
            throw new ConflictExecption("Email já cadastrado" + e.getCause());
        }
    }

    public boolean verificaEmailExistente(String email) {
        return usuarioRepository.existsByEmail(email);
    }
}
